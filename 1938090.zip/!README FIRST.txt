T10 SP Steam (11.1 build 21663693 2025-02-28) Offline Patch v1 (CAMPAIGN ONLY)

===============================
Instructions:
- Firstly, make sure the path on where you put the game folder is short and doesn't contain non latin characters or symbols to avoid issues with game launching.
- Extract everything in this archive into the root directory (has to be before sp24).
- Start the game ONLY FROM !start_sp24.bat and keep the console window open until it closes by itself when you close the game.
- If running !start_sp24.bat doesn't do anything, read the 1st step again (or check bootstrapper.log).

Hotkeys (Make sure that your keyboard is set to US keyboard first!):
- Cbuf: Right Control + / (press this hotkey in the external console window)
- Noclip: Right Control + N
- God Mode: Right Control + M

To set a different keybind for each hotkeys, modify the "virtual key codes" values in _profile.ini. The decimal values for each keyboard keys can be found in many places on the internet (search query: virtual key codes).
===============================

So even though they say that the campaign is online only, it is still possible to force the campaign portion of this game to be playable offline (with some limitations, check bottom notes). However, the multiplayer and zombies portions of this game will remain uncrackable for now since most of the required stuff are now server sided.

This crack uses some patches from Cyb1k's PS4 release of BO6 Campaign, so shoutout to them!

Steam notes:
This release uses a fork of GSE by alex47exe (originally created by Mr_Goldberg) for the steam emulator. You can change playername and language by editing steam_settings/configs.user.ini but make sure that you have installed the appropriate language files first.

Side notes:
- Savings is currently not working since they're all online, so every missions are unlocked by default
- Safehouse features like Acquistion Desk, upgrades, perks, etc. are currently not working, but the game can still be finished without using those features

.r4v3n
