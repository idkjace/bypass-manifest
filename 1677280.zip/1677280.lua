-- Generated Lua Manifest by Mythydra
-- Steam App 1677280 Manifest
-- Name: Company of Heroes 3
-- Generated: 2025-09-10 06:57:45
-- Total Depots: 6
-- Total DLCs: 5 (0 encrypted, 5 free)
-- Source: Steam AppInfo (steam-user)

-- MAIN APPLICATION
addappid(1677280) -- Company of Heroes 3

-- MAIN APP DEPOTS
addappid(228988,1,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Company of Heroes 3 Game Depot
setManifestid(228988,"6645201662696499616")
addappid(228990,1,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- Company of Heroes 3 Game Depot
setManifestid(228990,"1829726630299308803")
addappid(229006,1,"9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- Company of Heroes 3 Game Depot
setManifestid(229006,"1784011429307107530")
addappid(1677281,1,"946c1091854e4b36a1468dea11adb8fe4fe6db6485976132a50781a70d5a206e") -- Company of Heroes 3 Game Depot
setManifestid(1677281,"3410400171845343081")
addappid(1677282,1,"2dbe642c09395dcb0cfab68ff34eca066c3f47e38d8511d59509fb60cf7c665a") -- Company of Heroes 3 Game Depot
setManifestid(1677282,"8161104974131144885")
addappid(1677283,1,"") -- Company of Heroes 3 Game Depot (No Key)
setManifestid(1677283,"1956072617122484754")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2068340) -- Pre Order Content
addappid(2068341) -- Premium Content
addappid(2068342) -- Company of Heroes 3: Hammer & Shield Expansion Pack
addappid(3300460) -- Company of Heroes 3: Stealth & Stronghold
addappid(3469800) -- Company of Heroes 3: Fire & Steel
