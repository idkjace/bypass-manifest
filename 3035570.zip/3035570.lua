-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 3035570 Manifest
-- Name: Assassin's Creed Mirage
-- Generated: 2025-06-25 18:42:26
-- Total Depots: 11
-- Total DLCs: 19 (2 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3035570) -- Assassin's Creed Mirage

-- MAIN APP DEPOTS
addappid(3035571, 1, "e5d6ddfebd010fdb77b506a1d38d0c9a8929e5da7e35d812cc31b60996765be8") -- Depot 3035571
setManifestid(3035571, "3508643575109388440", 0)
addappid(3035572, 1, "6b8ab5f02c19f579e70f727bf5cf334dd677f79ce53f00d872838e45f5be8ff4") -- Depot 3035572
setManifestid(3035572, "6498603598890717095", 0)
addappid(3035573, 1, "0d3898c52be7bac07b224983d013dc1dc7f5604d012d8acf53705f27b2407f93") -- Depot 3035573
setManifestid(3035573, "898424073071536928", 0)
addappid(3035574, 1, "5fd1b7a0fcd0358604b077b36916c25306f56a02711bc81340adc8f931c14069") -- Depot 3035574
setManifestid(3035574, "6111328039693089051", 0)
addappid(3035575, 1, "bea37d2097d85084367b1081b989393012083fcc6645ce27cfa030594d99b8e4") -- Depot 3035575
setManifestid(3035575, "4861899127952541273", 0)
addappid(3035576, 1, "f3b973f43336ffe5eb19bf1005af5b1dd85c5549fb2d8bcffdbae21ad0ebcc49") -- Depot 3035576
setManifestid(3035576, "8132513443619807766", 0)
addappid(3035577, 1, "78c5bd2ce6e71c7bd10040111312fdb376ff42e7ba46acb57e99e0b9804c38a5") -- Depot 3035577
setManifestid(3035577, "8740522754259994455", 0)
addappid(3035578, 1, "a9edaf32fd28a1a2604b861adfd73d2cac3368a9db1699dafed5634581bd3986") -- Depot 3035578
setManifestid(3035578, "8901555832474035019", 0)
addappid(3035579, 1, "3fbd2da5efa4409f73ddbb97d7be0ca837c1d277ec0fc2a919071a6069f64333") -- Depot 3035579
setManifestid(3035579, "6984875896492391369", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3035580) -- Assassins Creed Mirage Ubisoft Activation
addappid(3230570) -- Assassins Creed Mirage - Master Assassin Upgrade Bundle 2
addappid(3230580) -- Assassins Creed Mirage - Master Assassin Upgrade Bundle 2 Ubisoft Activation
addappid(3230590) -- Assassins Creed Mirage - Master Assassin Upgrade Bundle 1
addappid(3230600) -- Assassins Creed Mirage - Master Assassin Upgrade Bundle 1 Ubisoft Activation
addappid(3230610) -- Assassins Creed Mirage - Guardian Pack
addappid(3230620) -- Assassins Creed Mirage - Guardian Pack Ubisoft Activation
addappid(3230630) -- Assassins Creed Mirage - Map Pack
addappid(3230640) -- Assassins Creed Mirage - Map Pack Ubisoft Activation
addappid(3230650) -- Assassins Creed Mirage - Deluxe Pack
addappid(3230660) -- Assassins Creed Mirage - Deluxe Pack Ubisoft Activation
addappid(3230670) -- Assassins Creed Mirage - Jinn Pack
addappid(3230680) -- Assassins Creed Mirage - Jinn Pack Ubisoft Activation
addappid(3230690) -- Assassins Creed Mirage - Lightning Pack
addappid(3230700) -- Assassins Creed Mirage - Lightning Pack Ubisoft Activation
addappid(3230710) -- Assassins Creed Mirage - Master Assassin Pack
addappid(3230720) -- Assassins Creed Mirage - Master Assassin Pack Ubisoft Activation
addappid(3230730) -- Assassins Creed Mirage - Fire Demon Pack
addappid(3230740) -- Assassins Creed Mirage - Fire Demon Pack Ubisoft Activation

-- EXCLUDED DLCS:
-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Assassins Creed Mirage - Deluxe Edition Ubisoft Activation (AppID: 3230750) - missing depot keys
-- addappid(3230750)
-- Assassins Creed Mirage -  Master Assassin Edition Ubisoft Activation (AppID: 3230760) - missing depot keys
-- addappid(3230760)
