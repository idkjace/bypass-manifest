-- Generated Lua Manifest Old Version By Fann
-- Server Discord: https://discord.com/invite/JwgVjY2A4A
-- Steam App 1113000 Manifest
-- Name: Persona 4 Golden
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1113000) -- Persona 4 Golden

-- MAIN APP DEPOTS
addappid(1113001, 1, "0f306d31499478d6f1a6971240693c21891f3887103f5f2c92766c20a91cc0ec") -- Day Content
setManifestid(1113001, "2386652974324010126", 0)
addappid(1113002, 1, "b10005d38f9cc7dd78f58cb736b8b8f2c9401087b8ac0a5386737bae70fe3a46") -- Day Depot
setManifestid(1113002, "2520901896865483548", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
