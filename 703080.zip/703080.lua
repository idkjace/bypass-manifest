-- Generated Lua Manifest by Mythydra
-- Steam App 703080 Manifest
-- Name: Planet Zoo
-- Generated: 2025-09-10 07:17:26
-- Total Depots: 4
-- Total DLCs: 22 (1 encrypted, 21 free)
-- Source: Steam AppInfo (steam-user)

-- MAIN APPLICATION
addappid(703080) -- Planet Zoo

-- MAIN APP DEPOTS
addappid(228987,1,"cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- Planet Zoo Game Depot
setManifestid(228987,"4302102680580581867")
addappid(703081,1,"bc33ccdea0df8610185dab43ef1f141daecf265e379acb2feb58fde38212796c") -- Planet Zoo Game Depot
setManifestid(703081,"1433938637340574266")
addappid(1098120,1,"9decae9ea2fe2d9055772fecad34b56835f0464dff8d4159d7457fc3586d2994") -- Planet Zoo Game Depot
setManifestid(1098120,"10163085496252241")

-- DLCS WITH DEDICATED DEPOTS (From AppInfo)
-- Deluxe Edition Extras (AppID: 1098120)
addappid(1098120)
addappid(1098120,1,"9decae9ea2fe2d9055772fecad34b56835f0464dff8d4159d7457fc3586d2994") -- Deluxe Edition Extras - Depot 1098120
setManifestid(1098120,"10163085496252241")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1098121) -- Deluxe Edition Animals
addappid(1196770) -- Planet Zoo: Arctic Pack
addappid(1238440) -- Planet Zoo: South America Pack
addappid(1349400) -- Planet Zoo: Australia Pack
addappid(1471590) -- Planet Zoo: Aquatic Pack
addappid(1567110) -- Planet Zoo: Southeast Asia Animal Pack
addappid(1647620) -- Planet Zoo: Africa Pack
addappid(1726150) -- Planet Zoo: Europe Pack
addappid(1747960) -- Planet Zoo: North America Animal Pack
addappid(1934140) -- Planet Zoo: Wetlands Animal Pack
addappid(2013290) -- Planet Zoo: Conservation Pack
addappid(2150050) -- Planet Zoo: Twilight Pack
addappid(2199210) -- Planet Zoo: Grasslands Animal Pack
addappid(2346830) -- Planet Zoo: Tropical Pack
addappid(2436600) -- Planet Zoo: Arid Animal Pack
addappid(2502240) -- Planet Zoo: Oceania Pack
addappid(2675740) -- Planet Zoo: Eurasia Animal Pack
addappid(2837730) -- Planet Zoo: Barnyard Animal Pack
addappid(3146420) -- Planet Zoo: Zookeepers Animal Pack
addappid(3473820) -- Planet Zoo: Americas Animal Pack
addappid(3586990) -- Planet Zoo: Asia Animal Pack
