-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2009100 Manifest
-- Name: Immortals of Aveum™
-- Generated: 2025-06-06 02:17:04
-- Total Depots: 2
-- Total DLCs: 5
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2009100) -- Immortals of Aveum™

-- MAIN APP DEPOTS
addappid(2009101, 1, "d86e611fab03143f2175ef5eca7adf37fec7226a43e3ea9fbe29331cd062917c") -- Main Game Content (Windows Content)
setManifestid(2009101, "1053383902706702983", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "550968249685141759", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2165170) -- Immortals of Aveum Deluxe Upgrade
addappid(2179880) -- Immortals of Aveum Pre-Purchase Content
addappid(2395350) -- Immortals of Aveum - Deluxe Preorder Edition - Key
addappid(2395351) -- Immortals of Aveum - Standard Preorder Edition - Key
addappid(2424221) -- Immortals of Aveum - Deluxe Edition - Key
