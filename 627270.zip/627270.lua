-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 627270 Manifest
-- Name: Injustice™ 2
-- Generated: 2025-06-06 02:41:32
-- Total Depots: 3
-- Total DLCs: 17 (6 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(627270) -- Injustice™ 2

-- MAIN APP DEPOTS
addappid(627271, 1, "7fa0ea96f7de44df35ea69af2de65094bb167d849e116d01707e30bb8739fb5b") -- Pachinko Content
setManifestid(627271, "1071315368466810106", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(704810) -- Starfire
addappid(731150) -- Demons Shader Pack
addappid(731160) -- Gods Shader Pack
addappid(731170) -- John Stewart
addappid(731171) -- Power Girl
addappid(731172) -- Reverse Flash
addappid(734280) -- Ultimate Pack
addappid(734281) -- Fighter Pack 1
addappid(734282) -- Fighter Pack 2
addappid(734283) -- Fighter Pack 3
addappid(747800) -- Black Lightning
addappid(759580) -- Atom
addappid(759581) -- Hellboy
addappid(779400) -- Enchantress
addappid(779401) -- TMNT
addappid(814250) -- Legendary Edition Unlocks
addtoken(814250, "9659940005629181344")
addappid(814251) -- Infinite Transforms

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(721260) -- Sub-Zero (no keys available)
-- addappid(721270) -- Darkseid (no keys available)
-- addappid(721280) -- Red Hood (no keys available)
-- addappid(721290) -- Brainiac (no keys available)
-- addappid(727980) -- Black Manta (no keys available)
-- addappid(727990) -- Raiden (no keys available)
