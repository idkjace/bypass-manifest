-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 1225580 Manifest
-- Name: Fe
-- Generated: 2025-06-05 15:16:56
-- Total Depots: 9
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(1225580) -- Fe

-- MAIN APP DEPOTS
addappid(1225581, 1, "d1be39e5675119d596e8dca09cd2e98486a3041a07ec4539f45487212fe3d47c") -- Fe - Content
setManifestid(1225581, "2920810115092745094", 0)
addappid(1225582, 1, "43b0c4a1d51f1da3c042f6552542e91f839a2d6dffcab7762173f46c7fc81a4d") -- Fe - en_US
setManifestid(1225582, "8791224522607658720", 0)
addappid(1225583, 1, "43cbe830ae87ad71ecd9530faa02602c3b20b84db5155e0858d06708d4e7b6c3") -- Fe - fr_FR
setManifestid(1225583, "1976473852220038241", 0)
addappid(1225584, 1, "951f2c85d637ead6e2ebb182658400faf7060325b2859111c3cd8f46f63c90c3") -- Fe - de_DE
setManifestid(1225584, "2262992852271294153", 0)
addappid(1225585, 1, "1e3ba205301eec08079daee0754146995d9629abdc78d13a64889e287f562d9d") -- Fe - it_IT
setManifestid(1225585, "1684013526022292874", 0)
addappid(1225586, 1, "75d2d3d50d41fd62ab3b75e23caad1da60bf92fa4d63bcf412469525286199f1") -- Fe - es_ES
setManifestid(1225586, "6670576466475314303", 0)
addappid(1225587, 1, "08686416c62a5cf1609851646757532dcd2579cd980236cd6a1dbc6c7c189a0a") -- Fe - ja_JP
setManifestid(1225587, "916330057324271359", 0)

-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 0)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1283300) -- Fe - Key
addtoken(1283300, "5248502408421326355")
