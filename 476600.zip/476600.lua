-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 476600 Manifest
-- Name: Call of Duty: WWII
-- Generated: 2025-06-05 03:05:45
-- Total Depots: 22
-- Total DLCs: 3
-- Shared Depots: 16

-- MAIN APPLICATION
addappid(476600) -- Call of Duty: WWII

-- MAIN APP DEPOTS
addappid(476601, 1, "831cdecf19668b10b3209e2889d22d39db73940b21ac18a35007bf587bf931cf") -- Call of Duty: WWII - Campaign Binary
setManifestid(476601, "1545824956507683106", 0)
addappid(476602, 1, "613f95c421e8081508651a80293faf846ea81e6f1e1a5c27398220ce12d6e2cb") -- Call of Duty: WWII - Campaign Content
setManifestid(476602, "3688161870357795857", 0)
addappid(476604, 1, "9d96074527f4d14f2ae748dc241d6c5a08ff8a1682b022128aca9a5e96479503") -- Call of Duty: WWII - MA
setManifestid(476604, "4157823044600597285", 0)
addappid(476603, 1, "ac9dcb534d5b6076fc179a3038eb8ad8aa079fa1acbf3e5db83f0d5413b97c14") -- Call of Duty: WWII - GA
setManifestid(476603, "765926368879116795", 0)
addappid(476606, 1, "4b7da74018117af93f3b22f8d7d146f9b3220ec37bdfb3ee8a959bbee51d6b1f") -- Call of Duty: WWII - MA English
setManifestid(476606, "361687800680072742", 0)
addappid(476605, 1, "dbac9cb02a7787a7511ff155d3a36b55a44cfcdc2b4444fa0f38965f531f57a5") -- Call of Duty: WWII - GA English
setManifestid(476605, "317554550655629178", 0)

-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)
addappid(476623, 1, "8fa86f77519a882e40cd8a3848d57ff06889bf8695927f1a6338c969d0e23886") -- Call of Duty: WWII - Shared Content (Shared from App 476620)
setManifestid(476623, "2715207186595524184", 0)
addappid(476624, 1, "1d4d24cbd1e63fa74eaa69af1a2322ee5bde330244c174720625642d3e7e97a9") -- Call of Duty: WWII - Shared English (Shared from App 476620)
setManifestid(476624, "1563345585010965365", 0)
addappid(476625, 1, "08751756af91bd6716f9006228ec904c7f0068bf98191ea23c24d0c883d0a415") -- Call of Duty: WWII -  Shared French (Shared from App 476620)
setManifestid(476625, "438552769716313064", 0)
addappid(476626, 1, "5af79b2113f71d6b76535c4e2e940f8132d23b16f94b373499eb3ff91b3baaf1") -- Call of Duty: WWII - Shared Italian (Shared from App 476620)
setManifestid(476626, "9199603757016024389", 0)
addappid(476627, 1, "3fc689108834ff85abe1102430d370184d3bb19deae7ac392b9788fd4973472b") -- Call of Duty: WWII -  Shared German (Shared from App 476620)
setManifestid(476627, "237148457619544546", 0)
addappid(476628, 1, "f2a5e157da4cea3e81bb38a25bf30d264b99db821607005647a5ddbfa5aabac3") -- Call of Duty: WWII -  Shared Spanish (Shared from App 476620)
setManifestid(476628, "1603528379199405449", 0)
addappid(476629, 1, "485023ebe6c4fdc853da3050e89cb2d065e165f9982bb2a776d315e8acbd98cd") -- Call of Duty: WWII - Shared Russian (Shared from App 476620)
setManifestid(476629, "1306356557700383733", 0)
addappid(476630, 1, "eeaa1cff3322bb1cb4cb2993e125919adf308edbbd290dc8783a6bbc9021bdc4") -- Call of Duty: WWII - Shared Polish (Shared from App 476620)
setManifestid(476630, "24454041969172048", 0)
addappid(476631, 1, "5627c146a1f0578bc5e0f35c5d3cbb9cd848e8df0c32594b7728a22db9f3bff6") -- Call of Duty: WWII - Shared Japanese (Shared from App 476620)
setManifestid(476631, "259314676018769709", 0)
addappid(476632, 1, "264b17b6637ec31b9da80248a5383615648afd9dfab5812d2f17db1f59aac468") -- Call of Duty: WWII - Shared Korean (Shared from App 476620)
setManifestid(476632, "3177361275812839742", 0)
addappid(476633, 1, "717937684daf349cb35af6235ba1aeac1ae7f0b6fa55186e24eb183cf8f8b07b") -- Call of Duty: WWII - Shared Simplified Chinese (Shared from App 476620)
setManifestid(476633, "3643356666802659610", 0)
addappid(476634, 1, "3f7e25ce26dc7bdf289a8077b628bf424a37bda213807b1d4bfa45ea72389b2b") -- Call of Duty: WWII - Shared Traditional Chinese (Shared from App 476620)
setManifestid(476634, "589337432719466650", 0)
addappid(476635, 1, "65109ea39a765ec04f9bff25c62e251655da249791ae5211ba4a36235b4a815f") -- Call of Duty: WWII - Shared Arabic-English (Shared from App 476620)
setManifestid(476635, "7372176855409048609", 0)
addappid(476636, 1, "d51749eddbb9d76ed9ebade554b62844c17099527affdd173734c2603e5bd32e") -- Call of Duty: WWII - Shared Brazilian Portuguese (Shared from App 476620)
setManifestid(476636, "6956787469155296651", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(683100) -- Call of Duty WWII - Season Pass
addappid(729160) -- Call of Duty WWII - Call of Duty Endowment Bravery Pack
addappid(848790) -- Call of Duty WWII - Call of Duty Endowment Fear Not Pack 
