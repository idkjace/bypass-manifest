-- Generated Lua Manifest Old Version By Fann
-- Steam App 1382330 Manifest
-- Name: Persona 5 Strikers
-- Generated: 2025-08-27 08:00:10
-- Total Depots: 6
-- Total DLCs: 2 (1 excluded)
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1382330) -- Persona 5 Strikers

-- MAIN APP DEPOTS
addappid(1382331, 1, "cb4d47b8650bd74db3b51a92cf07ad418d78b96bd67133d2b4b8b2a3d0ba9538") -- Gyoza Content
setManifestid(1382331, "3459946881652809066", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "8754764360237113396", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Persona 5 Strikers - Legacy BGM Pack (AppID: 1482080)
addappid(1482080)
addappid(1482080, 1, "9bc21e38df537abe2d78ec1c094aa47ba429892dde2f0104efc9fd1bc5bc4ea1") -- Persona 5 Strikers - Legacy BGM Pack - Persona 5 Strikers - Legacy BGM Pack (1482080) デポ
setManifestid(1482080, "1787045740467214444", 0)

-- Persona 5 Strikers - All-Out Attack Pack (AppID: 1482081)
addappid(1482081)
addappid(1482081, 1, "5fccb5605a330f3cf82a4a14924f83ea10e8a1264f86cf3dd89284f3e06abb03") -- Persona 5 Strikers - All-Out Attack Pack - Persona 5 Strikers - All-Out Attack Pack (1482081) デポ
setManifestid(1482081, "5354296267636021171", 0)

-- DLCS EXCLUDED (MISSING DEPOT KEYS)
-- Persona 5 Strikers - Bonus Content (AppID: 1523810) - missing keys for depots: [1382332, 1382332]
-- addappid(1523810)
-- addappid(1382332, 1, "2d11674fc11c6ebfab0a1ec662058d2ff40d80e4b968698c2e4fb9c2b5973ae7") -- Persona 5 Strikers - Bonus Content - BA_Test (excluded with DLC)
-- setManifestid(1382332, "5931759697087437203", 0)
-- addappid(1382332, 1, "2d11674fc11c6ebfab0a1ec662058d2ff40d80e4b968698c2e4fb9c2b5973ae7") -- Persona 5 Strikers - Bonus Content - BA_Test (excluded with DLC)
-- setManifestid(1382332, "5931759697087437203", 0)
