-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 924970 Manifest
-- Name: Back 4 Blood
-- Generated: 2025-06-04 22:55:58
-- Total Depots: 9
-- Total DLCs: 6
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(924970) -- Back 4 Blood

-- MAIN APP DEPOTS
addappid(924971, 1, "783767a483d935235bc2a46262a58b4acc3524bdf6d52116f090fcccc0a89024") -- Gobi [codename] Content
setManifestid(924971, "2194878379786247325", 0)
addappid(924972, 1, "ec1e4f563086da2780fdcb3f167c056d76e0c9ca49b6418b26d34ce26660ada7") -- B4B VO - fr-FR
setManifestid(924972, "7652397841777917928", 0)
addappid(924973, 1, "a729a752e939faa9c74e578c69b357cddf7d34ccd6c8564129117a16193fb003") -- B4B VO - de-DE
setManifestid(924973, "6035913895232866500", 0)
addappid(924974, 1, "28ab0aa9e98d603cd572c921b820931dedcf94882988a8d4aaaf5374394ec9d8") -- B4B VO - it-IT
setManifestid(924974, "8294287718880305251", 0)
addappid(924975, 1, "59f5fe1e63f36b4a43383d0f3eeef896f1375ff3a1d18bf5cd27c5756ff710fc") -- B4B VO - pt-BR
setManifestid(924975, "2770145798175310955", 0)
addappid(924976, 1, "1acba27ad19b4dd77a3130a775f5adeeebd0aa40ed3353f5cb80bfae583e60fd") -- B4B VO - es-ES
setManifestid(924976, "2838371652923164555", 0)
addappid(924977, 1, "bea7e2008e44c61676a5e44b067e4c637be848c3719337acb2cd55a1f7976693") -- B4B VO - es-MX
setManifestid(924977, "3599819504499511506", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1598440) -- Fort Hope Skin Pack
addtoken(1598440, "2290696036248583679")
addappid(1598441) -- Back 4 Blood Annual Pass
addappid(1598442) -- Ultimate Edition Content
addappid(1840320) -- Back 4 Blood - Expansion 1 Tunnels of Terror
addappid(2015180) -- Back 4 Blood - Expansion 2 Children of the Worm
addappid(2101940) -- Back 4 Blood - Expansion 3 River of Blood
