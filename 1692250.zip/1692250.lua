-- Generated Lua Manifest Old Version By Fann
-- Server Discord: https://discord.com/invite/JwgVjY2A4A
-- Steam App 1692250 Manifest
-- Name: F1® 22
-- Total Depots: 17
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1692250) -- F1® 22

-- MAIN APP DEPOTS
addappid(1692251, 1, "992e39e78da3738e7e2faf64fed30d2da3667df77ad24b33c8deddb98cc61a84") -- Main Game Content (Windows Content)
setManifestid(1692251, "2244211341195130480", 0)
addappid(1692252, 1, "47ee090a16626328c80160fe60a3661dd28c56c2126d700dcc01e02fd9346b95") -- Game Content (Linux Binaries)
setManifestid(1692252, "1256778826913932694", 0)
addappid(1692253, 1, "3776d8e2d1fe757f75693f8ecc2698371221bc125089fa6632539e82c432f200") -- Game Content (Mac Content)
setManifestid(1692253, "858451265935846213", 0)
addappid(1692254, 1, "5730b4105896b259a24cadee7ed9bc3d65d9fd17549d70b74b959105976d11a8") -- Common Library Files (Content)
setManifestid(1692254, "6963867595601668518", 0)
addappid(1692255, 1, "41b964fe4c2ee2c190793293a254f1c2ed06d991c09a17aef17b5a0c9845342a") -- Main Game Content (Depot 1692255)
setManifestid(1692255, "2207160135468858444", 0)
addappid(1692256, 1, "3ee9af629cf2aa81efde2fa99bd6b2139f8d6508a466edf45cffff231bcfadef") -- Main Game Content (Depot 1692256)
setManifestid(1692256, "3421398929435831297", 0)
addappid(1692257, 1, "8e7cc982badf49b58c9449fcd010fc567789e6a2c51326437296edefef0ab372") -- Main Game Content (Depot 1692257)
setManifestid(1692257, "3731118239929499491", 0)
addappid(1692258, 1, "b24a99a08115c318ee3c13ff10b406ac701dc168462d39e90789b42d709ecd22") -- Main Game Content (Depot 1692258)
setManifestid(1692258, "6101852295154845538", 0)
addappid(1692259, 1, "a4fcd88423adde5a84acabdf8f985dc752b931a25ce993f0d7070e0cbac34a1f") -- Main Game Content (Depot 1692259)
setManifestid(1692259, "6054764431810299827", 0)
addappid(1825270, 1, "82363e310ca8f34ee71bae6ec637a41a2c9365e48b729953fcfc74f452cf33f7") -- Game Content (Depot 1825270)
setManifestid(1825270, "5081329411283685911", 0)
addappid(1825271, 1, "d4ff2255749bffb1c05208e89314a9ea2ab2669a4f1cca236ab2c7e43a414ea9") -- Windows Content (Depot 1825271)
setManifestid(1825271, "3257664854483712793", 0)
addappid(1825272, 1, "cde853e37dcb1cca96fcd1b61cafc0569b5a4467658ca23b1eb76d87736349c2") -- Linux Content (Depot 1825272)
setManifestid(1825272, "1883553774509358626", 0)
addappid(1825273, 1, "e727b9336cee4ad290f8fb38bdfbb4e175515ce89588432c737f25c4158a4076") -- Mac Content (Depot 1825273)
setManifestid(1825273, "9119137431609156190", 0)
addappid(1825274, 1, "ab51285229bc552df6487cc607e2792fa44319f67e9b719cd22196adb16756e6") -- Game Content (Depot 1825274)
setManifestid(1825274, "7755099997799364683", 0)
addappid(1825275, 1, "689c79e0e40c080bd2a8ce1126d072a5a5f936b38bd21fc033a94a8e089e4536") -- Game Content (Depot 1825275)
setManifestid(1825275, "295892385664193180", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1903120) -- F1 22 - Preorder Content
addappid(1903140) -- F1 22 - Early Champions Content
addappid(1903141) -- F1 22 - Champions Content
addappid(1904900) -- F1 22 Champions Content Bundle
addappid(1904910) -- F1 22 - 5000 Pitcoins (pre order)
addappid(1904930) -- F1 22 - 18000 Pitcoins (deluxe)
addappid(2071940) -- F1 22 - EA Play Trial
