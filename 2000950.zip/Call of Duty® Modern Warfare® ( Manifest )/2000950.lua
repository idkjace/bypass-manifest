-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2000950 Manifest
-- Name: Call of Duty®: Modern Warfare®
-- Generated: 2025-06-05 03:09:35
-- Total Depots: 86
-- Total DLCs: 6 (2 excluded)

-- MAIN APPLICATION
addappid(2000950) -- Call of Duty®: Modern Warfare®

-- MAIN APP DEPOTS
addappid(2000951, 1, "89f7ea826aca3f28f0ece5ac9223a27bd632c3dbc4c32ca991ae009eb243bce6") -- Main Game Content (Windows Content)
setManifestid(2000951, "6017155528019757594", 0)
addappid(2117866, 1, "e9ef0c6b43a6035e487925421609ca5234e23e8cc7c70a81654f2cd08caa7095") -- Game Content (Depot 2117866)
setManifestid(2117866, "1199484232891708852", 0)
addappid(2000957, 1, "94f6cdb4a8744b280aad9748fa8fd4b7dfb5ea51e74f041a5b20a06ef4453ee8") -- Main Game Content (Depot 2000957)
setManifestid(2000957, "3882374967017007319", 0)
addappid(2000952, 1, "57ff9f6b88c52d489ad760dcdcd46e39eab6df8859089225d0953c3f40dad60a") -- Game Content (Linux Binaries)
setManifestid(2000952, "1024829292661433709", 0)
addappid(2117856, 1, "2070c9e68c871aa68a80cfb90af341340f4aac051bfc638c46ef387694fd6c18") -- Game Content (Depot 2117856)
setManifestid(2117856, "60731480537589453", 0)
addappid(2117486, 1, "2c5dd0200dfc656bb8686646cb95bfd9fcda8f86a425fbec9c0cbf785e4446b4") -- Game Content (Depot 2117486)
setManifestid(2117486, "3752244504154239818", 0)
addappid(2117811, 1, "f0f4f27aba7b9c6627ee98ed3116b3bb38c2c9807506b0c9d8b2b28f0586bb0e") -- Windows Content (Depot 2117811)
setManifestid(2117811, "324110229217810141", 0)
addappid(2117816, 1, "2d303675f6840f807487df98e8088d3a04245f47bda7f34ea0c9bb653692f412") -- Game Content (Depot 2117816)
setManifestid(2117816, "3113830547803140841", 0)
addappid(2117821, 1, "267e8b1ff50dbb5872f6a9da7ac339b60f2da935f84d7f791410ce316236f15a") -- Windows Content (Depot 2117821)
setManifestid(2117821, "2540473106604536091", 0)
addappid(2117826, 1, "c481044532c59f9b2e0af0a6711b90e49f5ce7a8bf2c989fe5946606b44dbe07") -- Game Content (Depot 2117826)
setManifestid(2117826, "1323478381403702897", 0)
addappid(2117831, 1, "93198d1d90d595e514bcb9e242439c46ba943f77346489d6bdfc0114f86238ca") -- Windows Content (Depot 2117831)
setManifestid(2117831, "2936250551668388717", 0)
addappid(2117836, 1, "7a4d7f0b29f5ae718a6046a8ca96b5e7deebe6b3a6527778ccbff9d2f65c998e") -- Game Content (Depot 2117836)
setManifestid(2117836, "7647822465015426953", 0)
addappid(2117841, 1, "117ee01c9b1fa6c8781a1cb0bb8a76c4a28dc7e2a8709ac20aad7920f73db3da") -- Windows Content (Depot 2117841)
setManifestid(2117841, "3596185142020440416", 0)
addappid(2117851, 1, "81d9112968df1dfd132366531852836e08832b09f92970ea4c5ef1bf51c437fb") -- Windows Content (Depot 2117851)
setManifestid(2117851, "9186461309581100713", 0)
addappid(2117846, 1, "4b11035eeee6eef4bafe2a3ad6ceb3691cfc30c0c02dc06cecd9ee85e7b6f1a5") -- Game Content (Depot 2117846)
setManifestid(2117846, "7410433615424253681", 0)
addappid(2117861, 1, "184f7159bded625641def2afebefdaf67ddabb66ef4171e2da259c603ff931c6") -- Windows Content (Depot 2117861)
setManifestid(2117861, "8741687829932014427", 0)
addappid(2117862, 1, "79b285054c897e6204fa34bbb97a2e55b76e2c8e30b94bcb5d3646b1389fe170") -- Linux Content (Depot 2117862)
setManifestid(2117862, "6866869535381833111", 0)
addappid(2117863, 1, "34b7468e556b723f4dc0d8416bfe6dcaf8f6974fbc59bd2519f804250db7da88") -- Mac Content (Depot 2117863)
setManifestid(2117863, "7199355712798984902", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Call of Duty Modern Warfare - Campaign (AppID: 2117480)
addappid(2117480)
addappid(2000958, 1, "f2e7f8186519b53eb498f3fabed994531863425687ad3718b86568e16222410c") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2000958, "5944912481176423077", 0)
addappid(2000953, 1, "858bb3da8ab9795e269659296d78e51ee4b74d68ef5ddb0bb5ea10667cbb1bf1") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2000953, "3382745380026668541", 0)
addappid(2117857, 1, "873ae9c209e1b65dab204c54715002f7a31eb15fdd8462d6fc69b0ea2c2a685f") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117857, "3088966385569583595", 0)
addappid(2117487, 1, "06f4a5d55acac5dc4c73eac606cdd1580621b80046dc83b82fc86eb4a5596099") -- Call of Duty Modern Warfare - Campaign - Main Content
setManifestid(2117487, "1590978317283340817", 0)
addappid(2117812, 1, "c19952e6e5599259b7417df0608a613e2a1b7d727dc8f2b29b45d6e6fb1a9b68") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117812, "8364685356463175404", 0)
addappid(2117817, 1, "210a64905c0e72eecdf6982fc189f5ec59aab4c66feac1c93643911f0d86ecd5") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117817, "2414178251577762024", 0)
addappid(2117822, 1, "78cfde88b40042dbb4aa270e6def0c9d65bba772fa4d3395fda543a7b308a04d") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117822, "2645550012776551238", 0)
addappid(2117827, 1, "cfbbf382d0972a49a367a2969903c24ae67994cebdb7d5867181e79122e39cf9") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117827, "1813021382389768668", 0)
addappid(2117832, 1, "f4bb13d0322112309648c14b3b975077781a37c88534fb6b2a0fe21518f8f18c") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117832, "7844885186663036702", 0)
addappid(2117837, 1, "34c05e6e2cb0016b6cf9d2362cbb6eb7d544ae19cdf1a7f3748e8389ebf2a2da") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117837, "8452129274559213797", 0)
addappid(2117842, 1, "6bd3201c31cf96cc7d5e76fa940b1b8c6d6093ea27389e648d6896ab062b55db") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117842, "4282261740899717283", 0)
addappid(2117852, 1, "dbd44f82659ca367a289c2b32f16c6fb19437d666c79b9882ef35736321ce5e3") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117852, "1003624582244363854", 0)
addappid(2117847, 1, "203fb757a8112ae1e22c87233b32bc406f7836a6a1dede5027e1ba1988e6f142") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117847, "5334903044796336957", 0)
addappid(2117480, 1, "b30d7e9f980080a493cc6d9f996d7bbe6cc08a39f308269511e3f105169785a5") -- Call of Duty Modern Warfare - Campaign - Main Content
setManifestid(2117480, "8956002737476455784", 0)
addappid(2117864, 1, "7d686aa7ed00c73fa06e74706deb6999ec3db30620abefc5ef1da667eefef3c5") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117864, "2173754400129234140", 0)
addappid(2117865, 1, "f7f1798ddfbd3c8c6de4e67d32c45c90be8cd8f32c2b1a8d1374fda71494be9a") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117865, "4538756931166093138", 0)
addappid(2117867, 1, "2fe5226cd0e4a875925baec6b78ad98c46df9d839b8c8e550d3d5ef71ca4686b") -- Call of Duty Modern Warfare - Campaign - DLC Content
setManifestid(2117867, "7795786779968442374", 0)

-- Call of Duty Modern Warfare - Multiplayer (AppID: 2117481)
addappid(2117481)
addappid(2000959, 1, "4685b681e73a868611c586755864591b5b4425bf7b9429c221ea1bd11bf2daeb") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2000959, "3975480440838983492", 0)
addappid(2000954, 1, "ae265d6aaa81de6d02655d4cf05ead37a9f6daa9dbe2ec5e82bc3d7e6444acd6") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2000954, "4092521335344146604", 0)
addappid(2117858, 1, "e119a8c34f040bec349615da54753c7b6f22cfcfd93bc89ceb5362c8459aef49") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117858, "8199973118161956692", 0)
addappid(2117488, 1, "c51db787b6c22dd27d4e588868bde77081d2f86ad609b581433edfb636c12e5c") -- Call of Duty Modern Warfare - Multiplayer - Main Content
setManifestid(2117488, "6561374842794936144", 0)
addappid(2117813, 1, "22cf64d5fff978c8fedbef6be350b82c5b26cd177a92b700858b4082f10ce32b") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117813, "8819930670137057612", 0)
addappid(2117818, 1, "17aa6fd931f943aae0f664b62621849b6663ffef600719fb575656fcfc624abf") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117818, "2186393543188172464", 0)
addappid(2117823, 1, "975a0857133f2aaac18964da678931ff6abd2283a024ece540531b36190a5ed4") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117823, "7528504682654402748", 0)
addappid(2117828, 1, "aec0ec94b514becb3b2488f75da2d1d69d8fe4047951052840218a59f0dcaa1a") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117828, "5565528271553329998", 0)
addappid(2117833, 1, "0b730276f61e41d60742010d22a944c082c7ea663f2f0658b0b2902a6c074537") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117833, "3709825031900175527", 0)
addappid(2117838, 1, "ff03c9afea48ac5ada40a7e0b06e7a4f97ed1e278971c6ed8c464c19eb1063b6") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117838, "6192900882703277554", 0)
addappid(2117843, 1, "73f40ea4869858907e67538d24e3f0a9e7b5ff67f4a47be836c0fe09eec1e718") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117843, "1082854964715604756", 0)
addappid(2117853, 1, "72514b6781efd11175a87d04ff731dab6afa34c7f3ed30b7ad26be829caf8d70") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117853, "1479092873031948131", 0)
addappid(2117848, 1, "0485802ea25f791a5280da7833f5820a278bc392fe7c7ee296f868e661834438") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117848, "3254612099216828424", 0)
addappid(2117481, 1, "96f907cc415e83c8f58e433eebbcd784c715cd1e98dfac28300f7adbbfc66e88") -- Call of Duty Modern Warfare - Multiplayer - Main Content
setManifestid(2117481, "266004134707841807", 0)
addappid(2117868, 1, "0de54f669c5e62652d73a59f71fd6a832dd03a5af8f8826988551535005188f0") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117868, "1243399334702429194", 0)
addappid(2117869, 1, "4e813ea37f0364a15502a291439e007f1256e30a1a404f68578a548d6b6f575a") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117869, "2340084693764676066", 0)
addappid(2117870, 1, "e11f890baeeed6f6cfeb93ce80ef6878814500cc26eedd789302471662e9531b") -- Call of Duty Modern Warfare - Multiplayer - DLC Content
setManifestid(2117870, "5695553151645508195", 0)

-- Call of Duty Modern Warfare - Special Ops (AppID: 2117482)
addappid(2117482)
addappid(2117484, 1, "4eeb929beb4dbddee341268c9e1f18f153996146a713fcccde136e7fc9f72662") -- Call of Duty Modern Warfare - Special Ops - Main Content
setManifestid(2117484, "7190573209684969178", 0)
addappid(2000955, 1, "b072c8687e7b1bf18630fc47399f9ad26e686b3ee24fdadd5753f1290b09f688") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2000955, "664144167151811770", 0)
addappid(2117859, 1, "53ebda1763790017a3f649fd10978da3e3732cdf305572e60253309ecbf453c1") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117859, "7487672552063866368", 0)
addappid(2117489, 1, "9b002ef61e588a3ce3c37081e2ccbe7251bfaaf8cde07d7d70f9413fc27ac867") -- Call of Duty Modern Warfare - Special Ops - Main Content
setManifestid(2117489, "3397793271798412310", 0)
addappid(2117814, 1, "896c7243b9c2308d9410a59ce45d85e185fd9684168be455c98b563825beadc5") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117814, "2923197037171383519", 0)
addappid(2117819, 1, "43845741efd3f63c973f0a51862cca1550b19f169f2568635c7fab116cef7df4") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117819, "3591067268116697795", 0)
addappid(2117824, 1, "b3bcdaaea6de86267fd62527f8dd07485656e8da23895008ca66fe010a64cb41") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117824, "6292817019320187353", 0)
addappid(2117829, 1, "6deef16c54334bbea7b6dc66c1a8a0c5f7938d6b81f447b9520a77ac893b6fd8") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117829, "1423937968636640048", 0)
addappid(2117834, 1, "62acee72fbcf2f84fa773c9ca66f58cf06204ffea824c776160afdba173c47d8") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117834, "3465918531067616415", 0)
addappid(2117839, 1, "06cff2cf6a7970d75ec019ec8b28c71a54fdec464ce74221eefef124f8c88541") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117839, "4299308759216831111", 0)
addappid(2117844, 1, "0194cedf7680461a258da83f8abef2d56c6ea189d8d8af343101c40bcc74ba7c") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117844, "3181137086099984265", 0)
addappid(2117854, 1, "e44e507f66c072da50e635823ea9edd5be3ea5f4331689610f862124bd199a6e") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117854, "2599233095317689724", 0)
addappid(2117849, 1, "41a919e7685e8ee92f6243f914220c7c9160b8571515527ad527946c3dce7836") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117849, "5700976001037368995", 0)
addappid(2117482, 1, "5a0589de96b4da9a4fc880f0219a3218a65221c266c147f79ab9a8b6a7e11a8d") -- Call of Duty Modern Warfare - Special Ops - Main Content
setManifestid(2117482, "2590547408989327287", 0)
addappid(2117871, 1, "c301e052d5aecaeb2ea252b556e881c8a8328edcde04b6d9b874fd57d144720a") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117871, "3481275803919713852", 0)
addappid(2117872, 1, "f10d073c69d0126b5fa698b6a32b0bc0d39f76a83684a72a3d320f9370c334a0") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117872, "8051769705790143484", 0)
addappid(2117873, 1, "625b4001fe7813e35a844bec562fd99b32a279e6de4f686c6222b49a7f02209d") -- Call of Duty Modern Warfare - Special Ops - DLC Content
setManifestid(2117873, "7645983416345498952", 0)

-- Call of Duty Modern Warfare - Survival (AppID: 2117483)
addappid(2117483)
addappid(2117485, 1, "01336e86308d7636051d72e7dfe6949b88a7c7a0f7ee9b61b92fd460d9f27a0d") -- Call of Duty Modern Warfare - Survival - Main Content
setManifestid(2117485, "3067922299560160858", 0)
addappid(2000956, 1, "e23db3a3276d705f77c53bc56fbd6fdc86a0060a59d02a68efa956dfc922dd82") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2000956, "3268268008651853268", 0)
addappid(2117860, 1, "58515ecee8146605e0da1703175e51dc9efd0b4101b8800c3816b2637fb9f417") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117860, "3277643581564502824", 0)
addappid(2117810, 1, "fd274693bfb21aed23531d0723f7fff4d766cc06da7367468f0d2e8a89b820f8") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117810, "793780619225096321", 0)
addappid(2117815, 1, "965a9a6a5a748e7e7b98607450adff55f6faa71313e0e89798a36df25f9d5420") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117815, "4548243029532480643", 0)
addappid(2117820, 1, "efc0b01141f5b78cfe0b997f1138cbd212a873c6809b47d121e07d3344fb7c2d") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117820, "7566109110514813464", 0)
addappid(2117825, 1, "8ed222c66c29e8f0a528d7b038bb20ba505a076683f1224272c7cc09021eb6f2") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117825, "4043250149975239507", 0)
addappid(2117830, 1, "6f0ff99c6f5953d88864f78b97de84ad85141a0cf1c1254d66ff71655baa1d5e") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117830, "7433746124213451687", 0)
addappid(2117835, 1, "427cf05dec59ca8bc132e79100c23c094c7475562885f14ad104c20d9fef03ea") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117835, "1671398824994437357", 0)
addappid(2117840, 1, "4bcd44ece1414872f57acfdac066320630d89cd2ccc2a7b88d26d047bf57c8d8") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117840, "1204760937435430288", 0)
addappid(2117845, 1, "db63c22901db67dc5d7ea89d775745ec3a95d4db4626591f0d187f02de724747") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117845, "2522257259249297100", 0)
addappid(2117855, 1, "177bfd32cee1a45372954c6d6535c292094680e9cfa88f9579e762f0a0451717") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117855, "1656015671458627363", 0)
addappid(2117850, 1, "2fa8bcb5562b970f78da2c673d19b99015d4421bd869d357e67daf760c4ddd8a") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117850, "2686218263607461538", 0)
addappid(2117483, 1, "9489358c333e79514f45ff156bb9ec62f785635d7e229cd19b498a762c230ebb") -- Call of Duty Modern Warfare - Survival - Main Content
setManifestid(2117483, "6748811224341884716", 0)
addappid(2117874, 1, "2d9305f024b00304b12a48b64ec304c40b09119b5a47160a47fb23bca974c4a8") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117874, "7597532883494377061", 0)
addappid(2117875, 1, "3dc3a17c0586376ec3644e5693a69378e848ee4023437316e74c9566c6e2b5b0") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117875, "3344631731387151194", 0)
addappid(2117876, 1, "e80b3f0701c6dad2216db326f6d99eeaefbe76d1871abcbca37075f67191ed5c") -- Call of Duty Modern Warfare - Survival - DLC Content
setManifestid(2117876, "22686318365723104", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2296310) -- Call of Duty Modern Warfare - CoD Points
addappid(2305260) -- Call of Duty Modern Warfare - XRK Weapons Pack

-- DLCS EXCLUDED (NO DEPOT KEYS, NO DEDICATED DEPOTS)
-- addappid(2282570) -- Call of Duty Endowment (C.O.D.E.) - Defender Pack (no keys available)
-- addappid(2282571) -- Call of Duty Warzone - Pro Pack (no keys available)
