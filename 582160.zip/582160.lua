-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 582160 Manifest
-- Name: Assassin's Creed Origins
-- Generated: 2025-06-25 06:44:59
-- Total Depots: 14
-- Total DLCs: 22
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(582160) -- Assassin's Creed Origins

-- MAIN APP DEPOTS
addappid(582161, 1, "8a326c0b4da80f5c0fceff46bb180dcec85f3a7bfccbbe886f72b76554158bae") -- Main Content
setManifestid(582161, "899343151187474389", 0)
addappid(582163, 1, "8b73cf590b16f3ddd4b6a765ab5e7db92eca028f0ca011231a07689e1090c903") -- Bra - Audio
setManifestid(582163, "8719200316416197317", 0)
addappid(582164, 1, "ea4d3242ce02b2007b8a5c1689ad1b91fe540d379da53645d7e854622d586e08") -- Fre - Audio
setManifestid(582164, "2665968185911542813", 0)
addappid(582165, 1, "d7eae89df7ae009b38f2c5f816c6e4b95e3132dfbf7d17318d36d44baf44c312") -- Ger - Audio
setManifestid(582165, "5204817986383847126", 0)
addappid(582166, 1, "7b16ae306a4b429f7a7bd082987732b197e2a0e5c20da339ca4e869137caf82d") -- Ita - Audio
setManifestid(582166, "5281665035933672010", 0)
addappid(582167, 1, "94e3348b5f53858df08d295feeea54fdd2bdc699dbfa4d02229397e13dfc40f7") -- Rus - Audio
setManifestid(582167, "2360141554958804953", 0)
addappid(582168, 1, "fed6f556c223abf9d56ee8353ea704ca7e2ffb8178cdc618941252bc3c2e91c3") -- Spa - Audio
setManifestid(582168, "319055195560046919", 0)
addappid(582169, 1, "e87fde80316a793368f114df1d49b86a00d9cc4f7d857923160900ff97b4a4be") -- Jap - Audio
setManifestid(582169, "5694571365631700045", 0)

-- SHARED DEPOTS (from other apps)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Assassins Creed Origins - The Hidden Ones (AppID: 662350)
addappid(662350)
addappid(660084, 1, "fba661c6ee698f367011611cfbf4edefc4613fcf2b90c077643e08bda518127d") -- Assassins Creed Origins - The Hidden Ones - DLC1
setManifestid(660084, "2134409271002682996", 0)

-- Assassins Creed Origins - The Curse Of The Pharaohs (AppID: 662351)
addappid(662351)
addappid(660085, 1, "d962d765069eb30826be3a4401f9f746a8793082b4a48dac32a87e4c19074dc0") -- Assassins Creed Origins - The Curse Of The Pharaohs - DLC2
setManifestid(660085, "4329630249127241901", 0)

-- Assassins Creed Origins - Roman Centurion Pack (AppID: 662352)
addappid(662352)
addappid(660081, 1, "617237848e1792b936aa6f862d9203a1cc6ebe59162923bda191681e773c66a5") -- Assassins Creed Origins - Roman Centurion Pack - Roman Centurion Pack
setManifestid(660081, "1246424898343738572", 0)

-- Assassins Creed Origins - Horus Pack (AppID: 662353)
addappid(662353)
addappid(660082, 1, "256948a62c4e67514eba700c0081ae366b428052e026c1b967e5f19c7da09355") -- Assassins Creed Origins - Horus Pack - Horus Pack
setManifestid(660082, "6873063169339276628", 0)

-- Assassins Creed Origins - Desert Viper Pack (AppID: 722300)
addappid(722300)
addappid(660083, 1, "9f84ead601362489c2465704a97b6aac7f91a1195dede5847556b51379313056") -- Assassins Creed Origins - Desert Viper Pack - Desert Viper Pack
setManifestid(660083, "5816920034497408068", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(648280) -- Assassins Creed Origins - RU-CN Standard Preorder - Uplay Activation
addappid(648281) -- Assassins Creed Origins - WW Standard Preorder - Uplay Activation
addappid(648282) -- Assassins Creed Origins - RU-CN Deluxe Preorder - Uplay Activation
addappid(648283) -- Assassins Creed Origins - WW Deluxe Preorder - Uplay Activation
addappid(648284) -- Assassins Creed Origins - RU-CN Gold Preorder - Uplay Activation
addappid(648285) -- Assassins Creed Origins - WW Gold Preorder - Uplay Activation
addappid(660080) -- Assassins Creed Origins - Season Pass
addappid(662354) -- Assassins Creed Origins - Horus Pack Uplay Activation
addappid(662355) -- Assassins Creed Origins - Roman Centurion Pack Uplay Activation
addappid(662356) -- Assassins Creed Origins - The Curse Of The Pharaohs Uplay Activation
addappid(662357) -- Assassins Creed Origins -  The Hidden Ones Uplay Activation
addappid(683850) -- Assassins Creed Origins - Deluxe Pack
addappid(683860) -- Assassins Creed Origins - Deluxe Pack Uplay Activation
addappid(736940) -- Assassins Creed Origins - Standard - Uplay Activation
addappid(736941) -- Assassins Creed Origins - Deluxe - Uplay Activation
addappid(736942) -- Assassins Creed Origins - Gold - Uplay Activation
addappid(737850) -- Assassins Creed Origins - Season Pass - Uplay Activation
