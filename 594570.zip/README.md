# Total War: WARHAMMER II DLC Package (AppInfo Generated)

Generated for App ID: 594570
Game: Total War: WARHAMMER II
Source: Steam AppInfo (steam-user)
