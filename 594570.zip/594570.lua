-- Generated Lua Manifest by Mythydra
-- Steam App 594570 Manifest
-- Name: Total War: WARHAMMER II
-- Generated: 2025-09-10 07:24:41
-- Total Depots: 135
-- Total DLCs: 45 (10 encrypted, 35 free)
-- Source: Steam AppInfo (steam-user)

-- MAIN APPLICATION
addappid(594570) -- Total War: WARHAMMER II

-- MAIN APP DEPOTS
addappid(228983,1,"77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- Total War: WARHAMMER II Game Depot
setManifestid(228983,"8124929965194586177")
addappid(228985,1,"21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- Total War: WARHAMMER II Game Depot
setManifestid(228985,"3966345552745568756")
addappid(228988,1,"1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- Total War: WARHAMMER II Game Depot
setManifestid(228988,"6645201662696499616")
addappid(228990,1,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- Total War: WARHAMMER II Game Depot
setManifestid(228990,"1829726630299308803")
addappid(372531,1,"85fd9e7e0a0f07b17dcb14263b94e436306270f02200d7a6669de0ba70602504") -- Total War: WARHAMMER II Game Depot
setManifestid(372531,"1128077100884847891")
addappid(594571,1,"d8cba4607b87db3f1dfd22c820eabb8cb8c89c8a2dd065ef355621f5f3ba2443") -- Total War: WARHAMMER II Game Depot
setManifestid(594571,"7127270112881211021")
addappid(594572,1,"a3a7d64b8c65727516bc46204620c095b833e3932e09666dd0adb8670cf3e2b1") -- Total War: WARHAMMER II Game Depot
setManifestid(594572,"8150756157514541078")
addappid(594573,1,"dea1a1b48fec488dbee4638a96322915348a64d617004c9e1fa1c68333008ac3") -- Total War: WARHAMMER II Game Depot
setManifestid(594573,"5829353196720758004")
addappid(594574,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594574,"4977697010239549019")
addappid(594575,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594575,"5466497385248043079")
addappid(594576,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594576,"3941613999444074580")
addappid(594577,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594577,"8737574832068189348")
addappid(594578,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594578,"6782744123935192244")
addappid(594579,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594579,"9214767514064515913")
addappid(594590,1,"447e4b18f20264433b4976adfd576f48bf74bc402d7712d624d157af66c6af2a") -- Total War: WARHAMMER II Game Depot
setManifestid(594590,"7163359287625511573")
addappid(594591,1,"d42e24f4b9e19d5d7d65e95bd3e3756ad368fd54539a192c4835394cd1279750") -- Total War: WARHAMMER II Game Depot
setManifestid(594591,"3400047461133253732")
addappid(594592,1,"a518a7f671667bac8906647798824b5c1bff7000c87b6de0ba8d3fa7767f70c8") -- Total War: WARHAMMER II Game Depot
setManifestid(594592,"4597721149903950828")
addappid(594593,1,"9de2f07eb28bdadaebd7aee1548e0e28315c7d305121474d077b641fe6871083") -- Total War: WARHAMMER II Game Depot
setManifestid(594593,"3382257922075203738")
addappid(594594,1,"333fe11c9fbfeb076479ac2250f07d799ff9a32be089a4ed65db3307b795bab9") -- Total War: WARHAMMER II Game Depot
setManifestid(594594,"715652375034881947")
addappid(594595,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(594597,1,"0b505138935a01af23357f51decc7efd1b1cb2530eca2987f4e10f5ace139348") -- Total War: WARHAMMER II Game Depot
setManifestid(594597,"2413821512598321032")
addappid(594598,1,"88dd9d96a4892a523a4e37b6aeb93c3b0061bb5869a86a9f74b7d031697f8172") -- Total War: WARHAMMER II Game Depot
setManifestid(594598,"5005672322067666324")
addappid(594599,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(594600,1,"d62804cc394a667461878557dcbe10b581e0acb5e4f96e0ccde14f3449b18aa7") -- Total War: WARHAMMER II Game Depot
setManifestid(594600,"2819893851616154301")
addappid(594601,1,"9615e4cdd5504955fbe2657e08b92358cf926fc8ee28c563c6df2ad41d3eddbd") -- Total War: WARHAMMER II Game Depot
setManifestid(594601,"7936699279323443651")
addappid(594604,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594604,"1493057519497771362")
addappid(594605,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594605,"562487958878779840")
addappid(594606,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594606,"1477252846435221188")
addappid(594607,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594607,"3032271098459130305")
addappid(594608,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594608,"5318795897960945484")
addappid(594609,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(594609,"1128844478804298615")
addappid(617810,1,"afd5387ac9ed02be13a9bd095d741c61281ed5fd381adc7e9dbcc8f381be6e96") -- Total War: WARHAMMER II Game Depot
setManifestid(617810,"5588365124732151440")
addappid(617811,1,"1058333d96b0038279a5edb49343ba35c083b95f03c974958945455518b2fc14") -- Total War: WARHAMMER II Game Depot
setManifestid(617811,"3325703992368297547")
addappid(617812,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617812,"306049789179561823")
addappid(617813,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617813,"9157039407744523083")
addappid(617814,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617814,"5543193207272899205")
addappid(617815,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617815,"6820295545341628871")
addappid(617816,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617816,"5984279755190488610")
addappid(617817,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617817,"8904169434561639426")
addappid(617818,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617818,"6192825606733410983")
addappid(617819,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617819,"7526456021785081952")
addappid(617870,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(617871,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617871,"1914836205842858611")
addappid(617872,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617872,"3950332451811012105")
addappid(617873,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617873,"8163150537862365866")
addappid(617874,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617874,"283375590943455471")
addappid(617875,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617875,"2917384631866798901")
addappid(617876,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(617877,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(617878,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617878,"5493826480216555699")
addappid(617879,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(617879,"8966681429444124298")
addappid(732961,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(732962,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(732962,"5126721205952149686")
addappid(732963,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(732964,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(732964,"6217848260954776959")
addappid(732965,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(732965,"6224557063870392709")
addappid(732966,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(732966,"3683846612451856105")
addappid(732967,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(732968,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(732968,"3409337803450082040")
addappid(732969,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(735421,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735421,"3371539156487977743")
addappid(735422,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735422,"5945347286990161583")
addappid(735423,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735423,"2984043869614983699")
addappid(735424,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735424,"936108984159193405")
addappid(735425,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735425,"4458690294487969027")
addappid(735426,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735426,"4724455040445019075")
addappid(735427,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735427,"8908019143591155854")
addappid(735428,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735428,"4342528889933766086")
addappid(735429,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(735429,"6664180135053395553")
addappid(779881,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779881,"2273187739270757233")
addappid(779882,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779882,"4151104484546655204")
addappid(779883,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779883,"7886726420159314990")
addappid(779884,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779884,"4315800310009089883")
addappid(779885,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779885,"1416668433166032368")
addappid(779886,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779886,"4009140348681290244")
addappid(779887,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(779887,"8503966949919467460")
addappid(779888,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(779889,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(781191,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781191,"1078092675611880446")
addappid(781192,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781192,"770013585497844424")
addappid(781193,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(781194,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781194,"3548442894890418924")
addappid(781195,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(781196,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781196,"8675872537469550000")
addappid(781197,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781197,"3688452895874564043")
addappid(781198,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(781198,"1681896073245901869")
addappid(781199,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(794112,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(794112,"257740271443570451")
addappid(794113,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(794114,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(794114,"5159875925547585429")
addappid(794115,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(794115,"5384870003882555189")
addappid(794116,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
setManifestid(794116,"670116436287198609")
addappid(965220,1,"") -- Total War: WARHAMMER II Game Depot (No Key)
addappid(1036390,1,"") -- Total War: WARHAMMER II Game Depot (No Key)

-- DLCS WITH DEDICATED DEPOTS (From AppInfo)
-- Total War: WARHAMMER II - Chaos Warriors Race Pack (AppID: 594590)
addappid(594590)
addappid(594590,1,"447e4b18f20264433b4976adfd576f48bf74bc402d7712d624d157af66c6af2a") -- Total War: WARHAMMER II - Chaos Warriors Race Pack - Depot 594590
setManifestid(594590,"7163359287625511573")

-- Total War: WARHAMMER II - Blood for the Blood God II (AppID: 594591)
addappid(594591)
addappid(594591,1,"d42e24f4b9e19d5d7d65e95bd3e3756ad368fd54539a192c4835394cd1279750") -- Total War: WARHAMMER II - Blood for the Blood God II - Depot 594591
setManifestid(594591,"2974146650303045528")

-- Total War: WARHAMMER II - Call of the Beastmen (AppID: 594592)
addappid(594592)
addappid(594592,1,"a518a7f671667bac8906647798824b5c1bff7000c87b6de0ba8d3fa7767f70c8") -- Total War: WARHAMMER II - Call of the Beastmen - Depot 594592
setManifestid(594592,"4871266084550441708")

-- Total War: WARHAMMER II - The Grim and the Grave (AppID: 594593)
addappid(594593)
addappid(594593,1,"9de2f07eb28bdadaebd7aee1548e0e28315c7d305121474d077b641fe6871083") -- Total War: WARHAMMER II - The Grim and the Grave - Depot 594593
setManifestid(594593,"3382257922075203738")

-- Total War: WARHAMMER II - The King and the Warlord (AppID: 594594)
addappid(594594)
addappid(594594,1,"333fe11c9fbfeb076479ac2250f07d799ff9a32be089a4ed65db3307b795bab9") -- Total War: WARHAMMER II - The King and the Warlord - Depot 594594
setManifestid(594594,"715652375034881947")

-- Total War: WARHAMMER II - Realm of The Wood Elves (AppID: 594597)
addappid(594597)
addappid(594597,1,"0b505138935a01af23357f51decc7efd1b1cb2530eca2987f4e10f5ace139348") -- Total War: WARHAMMER II - Realm of The Wood Elves - Depot 594597
setManifestid(594597,"6326090585399089172")

-- Total War: WARHAMMER II - Bretonnia (AppID: 594598)
addappid(594598)
addappid(594598,1,"88dd9d96a4892a523a4e37b6aeb93c3b0061bb5869a86a9f74b7d031697f8172") -- Total War: WARHAMMER II - Bretonnia - Depot 594598
setManifestid(594598,"1110252603145927208")

-- Total War: WARHAMMER II - Jade Wizard (AppID: 594600)
addappid(594600)
addappid(594600,1,"d62804cc394a667461878557dcbe10b581e0acb5e4f96e0ccde14f3449b18aa7") -- Total War: WARHAMMER II - Jade Wizard - Depot 594600
setManifestid(594600,"2819893851616154301")

-- Total War: WARHAMMER II - Grey Wizard (AppID: 594601)
addappid(594601)
addappid(594601,1,"9615e4cdd5504955fbe2657e08b92358cf926fc8ee28c563c6df2ad41d3eddbd") -- Total War: WARHAMMER II - Grey Wizard - Depot 594601
setManifestid(594601,"7936699279323443651")

-- Total War: WARHAMMER II - Mortal Empires (AppID: 617810)
addappid(617810)
addappid(617810,1,"afd5387ac9ed02be13a9bd095d741c61281ed5fd381adc7e9dbcc8f381be6e96") -- Total War: WARHAMMER II - Mortal Empires - Depot 617810
setManifestid(617810,"652818519393742084")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(594595) -- Total War: WARHAMMER II - Wurrzag
addappid(594596) -- Total War: WARHAMMER II - Grombrindal The White Dwarf
addappid(594599) -- Total War: WARHAMMER II - Isabella von Carstein
addappid(594602) -- Total War: WARHAMMER II - Krell
addappid(594603) -- Total War: WARHAMMER II - Norsca
addappid(617870) -- Total War: WARHAMMER II - Rise of the Tomb Kings
addappid(732960) -- Total War: WARHAMMER II - 30th Anniversary Regiments
addappid(735420) -- Total War: WARHAMMER II - Tretch Craventail
addappid(779880) -- Total War: WARHAMMER II - The Queen & The Crone
addappid(781190) -- Total War: WARHAMMER II - Steps of Isha
addappid(794110) -- Total War: WARHAMMER II - Alith Anar
addappid(794111) -- Total War: WARHAMMER II - Bone Giant
addappid(835670) -- Total War: WARHAMMER II - Curse of the Vampire Coast
addappid(835671) -- Total War: WARHAMMER II - Lokhir Fellheart
addappid(965220) -- Total War: WARHAMMER II - The Prophet & The Warlock
addappid(1003160) -- Total War: WARHAMMER II - Tiktaq'to
addappid(1036390) -- Total War: WARHAMMER II - Amethyst Wizard
addappid(1074320) -- Total War: WARHAMMER II - The Hunter and the Beast
addappid(1074321) -- Total War: WARHAMMER II - Gor-Rok
addappid(1083060) -- Total War: WARHAMMER II - Gotrek & Felix
addappid(1158180) -- Total War: WARHAMMER II - The Shadow & The Blade
addappid(1158181) -- Total War: WARHAMMER II - Repanse de Lyonesse
addappid(1209120) -- Total War: WARHAMMER II - The Warden & The Paunch
addappid(1209121) -- Total War: WARHAMMER II - Imrik
addappid(1244670) -- Total War: WARHAMMER II - Black Orc Big Boss
addappid(1264270) -- Total War: WARHAMMER II - Catchweb Spidershrine
addappid(1315750) -- Total War: WARHAMMER II – The Twisted & The Twilight
addappid(1315751) -- Total War: WARHAMMER II - Skaven Chieftain
addappid(1315752) -- Total War: WARHAMMER II – Drycha
addappid(1423860) -- Total War: WARHAMMER II – Glade Captain
addappid(1517260) -- Total War: WARHAMMER II - Rakarth
addappid(1556110) -- Total War: WARHAMMER II – The Silence & The Fury 
addappid(1576390) -- Total War: WARHAMMER II - Thorek Ironbrow
addappid(1576450) -- Total War: WARHAMMER II - Great Bray Shaman
addappid(1576460) -- Total War: WARHAMMER II - Ogre Mercenaries
