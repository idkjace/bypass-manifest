-- Generated Lua Manifest Old Version By Fann
-- Server Discord: https://discord.com/invite/JwgVjY2A4A
-- Steam App 1811260 Manifest
-- Name: EA SPORTS™ FIFA 23
-- Total Depots: 24
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1811260) -- EA SPORTS™ FIFA 23

-- MAIN APP DEPOTS
addappid(1811261, 1, "45403f0e21821c85fc608a60a88f1e62b5a4c3a84a8c6c54702160f1c772d8b8") -- Main Game Content (Windows Content)
setManifestid(1811261, "4625899733252360131", 0)
addappid(1811262, 1, "b9813c20ae1b98a8bcf896a1c09bfbc8ee68d296359c29b31f8c79b291a80a92") -- Game Content (Linux Binaries)
setManifestid(1811262, "6609786367939563032", 0)
addappid(1811263, 1, "ba0d2baa9817ab0800f61c6b0f3239be4f664e5fc4f43a9cade45daa892e900e") -- Game Content (Mac Content)
setManifestid(1811263, "5939550779247785108", 0)
addappid(1811264, 1, "eac479a706d9fd014659f85aac64f37faed1ffaaabe06756f29ef603ddf223ff") -- Common Library Files (Content)
setManifestid(1811264, "2561041771121344777", 0)
addappid(1811265, 1, "29995c19c74e7da29773ba38663e5d8605ffc84fabe0ab61dc805e95299355ad") -- Main Game Content (Depot 1811265)
setManifestid(1811265, "3211470369461987211", 0)
addappid(1811266, 1, "78b80bfbda4d0590a323ac842501e1d905999f74acb41f7b59552ef42617cd70") -- Main Game Content (Depot 1811266)
setManifestid(1811266, "5945115728340807207", 0)
addappid(1811267, 1, "89e004fd62923102c3aa5c716109e2a001ad86d76164896c89ba8364ef4361b2") -- Main Game Content (Depot 1811267)
setManifestid(1811267, "1183552119216351845", 0)
addappid(1811268, 1, "c15ea267e0007ea9f470d50ead809a1b6a2f105f749af23ad46968d7a350e6ac") -- Main Game Content (Depot 1811268)
setManifestid(1811268, "5682019268194334987", 0)
addappid(1811269, 1, "74bc1016aa39b149d198164953e0f68c429cf0db7d08bdb3f559efb987b425ae") -- Main Game Content (Depot 1811269)
setManifestid(1811269, "170129674632322616", 0)
addappid(1811271, 1, "d4122b577d555718301cf1444c8d8e92d1e5cc708206f27c8eacb53e50a29b28") -- Windows Content (Depot 1811271)
setManifestid(1811271, "2864192962970758010", 0)
addappid(1811272, 1, "57b857831399b0ad846ba63d83e6090452b55ea6cd82c36638a4dc437a95911a") -- Linux Content (Depot 1811272)
setManifestid(1811272, "7371958561375026575", 0)
addappid(1811273, 1, "1d7404f94eb436438c9f14d6d84de4919084c797831b4ca936476cdfe84f1a43") -- Mac Content (Depot 1811273)
setManifestid(1811273, "1948482439034239548", 0)
addappid(1811274, 1, "4d16fc97cdc2c2c535eb77bb1e9ba136a9b6e69ae801b23d87607efcfbd73754") -- Game Content (Depot 1811274)
setManifestid(1811274, "4362691205218335418", 0)
addappid(1811275, 1, "e5611f825dd5fe5b4f12b1d1c54b95f2a72bb75a429ada31cde8ef98dd13b55a") -- Game Content (Depot 1811275)
setManifestid(1811275, "4521958270811026783", 0)
addappid(1811276, 1, "8d8723e47abeee060516de45932439ba5fd684253ffc2aa02fa215a03180c8f1") -- Game Content (Depot 1811276)
setManifestid(1811276, "8107289000101647416", 0)
addappid(1811277, 1, "0e6058e9f6023da78c3fb8d4f5f3100635f3366e94826d99a698149131dcde90") -- Game Content (Depot 1811277)
setManifestid(1811277, "3419770175857211498", 0)
addappid(1811278, 1, "0fcd350a3915aba75f6432dec12cd76d88dce75d3ef71d5bdd1e19563a5e807a") -- Game Content (Depot 1811278)
setManifestid(1811278, "7717356334266630406", 0)
addappid(1811279, 1, "b4eee7bc8f6722e37256a3abdf8a39cdb199e4c15fbd2b1ca001fb9d9110fbd3") -- Game Content (Depot 1811279)
setManifestid(1811279, "5404084227688936502", 0)
addappid(1827531, 1, "c958682c696e0e3f61f7ad5a6781967c2b3297776490bfba42edec251a70e521") -- Windows Content (Depot 1827531)
setManifestid(1827531, "8224521596096784122", 0)
addappid(1827532, 1, "26cb891fd3e2e5a5170917abbeb913e959e5929d7ab0738466debdb825009c48") -- Linux Content (Depot 1827532)
setManifestid(1827532, "4001711097757269715", 0)
addappid(1827533, 1, "77208a881d2a259194121ce4e1bb16675c8ef8a20f9886883044bc13fb87a92b") -- Mac Content (Depot 1827533)
setManifestid(1827533, "6523375598578045753", 0)
addappid(1827534, 1, "cfc6ac19afbbd65ce875f73b5960c3e396f791f1cb5f47bcb79dcc182e0f7040") -- Game Content (Depot 1827534)
setManifestid(1827534, "4609501439421070082", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(229002, 1, "f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738") -- .NET 4.0 Redist (Shared from App 228980)
setManifestid(229002, "7260605429366465749", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1811270) -- FIFA 23 - Standard Edition Key
addappid(1827530) -- FIFA 23 - EA Play Trial Key
addappid(1962390) -- FIFA 23 - Standard Edition Preorder Key
addappid(1962391) -- FIFA 23 - Ultimate Edition Key
addappid(1962392) -- FIFA 23 - Ultimate Edition (Early) Preorder Key
addappid(1962393) -- FIFA 23 - Ultimate Edition (Late) Preorder Key
addappid(2224220) -- EA SPORTS FIFA 23 Ultimate Team Starter Bundle
