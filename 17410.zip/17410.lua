-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 17410 Manifest
-- Name: Mirror's Edge
-- Generated: 2025-06-06 10:51:26
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(17410) -- Mirror's Edge

-- MAIN APP DEPOTS
addappid(17411, 1, "c33850de7b7ffdf3471a48d9ed25096128125048fc3cf3ad70917e07b868cb8d") -- mirrors edge content
setManifestid(17411, "9029786093119423801", 0)
