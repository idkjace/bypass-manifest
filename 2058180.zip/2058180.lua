-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2058180 Manifest
-- Name: Judgment
-- Generated: 2025-06-06 03:53:40
-- Total Depots: 10
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2058180) -- Judgment

-- MAIN APP DEPOTS
addappid(2058181, 1, "2c5b08fe950ac2f5fcfc838f3ebcf0f1863bcb65ffc05bb859d1e3f8cd20fb99") -- Main Game Content (Windows Content)
setManifestid(2058181, "8035707233626484552", 0)
addappid(2058182, 1, "f6aa46579ab78cdede9b725040ae992a922876dc88c3d0b4d51f1de8dca091d7") -- Game Content (Linux Binaries)
setManifestid(2058182, "2945639909247876092", 0)
addappid(2058183, 1, "362b005a854a2281f863b2b29a2d4cdf14c0038bd1593d80eae2845a023c748a") -- Game Content (Mac Content)
setManifestid(2058183, "6902293912600710880", 0)
addappid(2058184, 1, "8e74fca7757729e2611867385eb27efcdac8eb374d28dd0d6a783c25a852f6d4") -- Common Library Files (Content)
setManifestid(2058184, "2894483093347645518", 0)
addappid(2058185, 1, "a26ec42bcfcd2d33dfe90f40d4354dcc0e4a5345c55ae1bea3e70d5bd19164b4") -- Main Game Content (Depot 2058185)
setManifestid(2058185, "1892906999181499702", 0)
addappid(2058186, 1, "89fd458eaee9f9f95bbd9ebd4198b2ebbdd31e4757ee89dee2de1822755476a0") -- Main Game Content (Depot 2058186)
setManifestid(2058186, "532774351515253971", 0)
addappid(2058187, 1, "6392203a125860c340a4115737d0a6f44929bf4def0f4e18db19c1e917078387") -- Main Game Content (Depot 2058187)
setManifestid(2058187, "508766208648227258", 0)
addappid(2058188, 1, "94548f8725ca5a1ab85f479f30ab6c987c1f92b16d3a51a1601ea4705db12ba3") -- Main Game Content (Depot 2058188)
setManifestid(2058188, "2209049931727278392", 0)
addappid(2058189, 1, "fd84527ae76dc442a8ad74d9293d136400bfe79a532dc323d21790b2b9021bed") -- Main Game Content (Depot 2058189)
setManifestid(2058189, "930300468467287281", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
