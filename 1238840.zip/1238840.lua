-- Generated Lua Manifest Old Version By Fann
-- Server Discord: https://discord.com/invite/JwgVjY2A4A
-- Steam App 1238840 Manifest
-- Name: Battlefield™ 1
-- Total Depots: 16
-- Total DLCs: 18
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1238840) -- Battlefield™ 1

-- MAIN APP DEPOTS
addappid(1238841, 1, "cb8c758a6b306785d05f63438a35661ee32cdf1d1cff46d1fbd1b2b9ae6c77e5") -- Telstar - BF1 Content
setManifestid(1238841, "1321309571720695350", 0)
addappid(1238842, 1, "01d2655d5a322102278109ba650ef63f0af559005c03c42f488fa9ea838c5360") -- Battlefield 1 - en_US
setManifestid(1238842, "5333154250492374829", 0)
addappid(1238843, 1, "ef63e230db178de5ba83fe6db0e126e49ea50b5b013c3a9446c196d76a0a188e") -- Battlefield 1 - fr_FR
setManifestid(1238843, "2553483208957014562", 0)
addappid(1238844, 1, "563c64c4a8a03b132f383a1b283f4dede43590fbf82517f56ee0dd7172cafc11") -- Battlefield 1 - de_DE
setManifestid(1238844, "297450565869601615", 0)
addappid(1238845, 1, "1d36de8d8f5ca5ae60eeda4a3d622884bd05a8aa462fb98d56e2ec926baedc10") -- Battlefield 1 - es_ES
setManifestid(1238845, "8622125037850065623", 0)
addappid(1238846, 1, "9f72127c998d8db2f4118827aef531fffd5ad1ff33ce6bdb55249ce4de669f65") -- Battlefield 1 - it_IT
setManifestid(1238846, "4270100579184161827", 0)
addappid(1238847, 1, "50851f77684e1cab0648488e5630ee614085e5cec453fe5c0f57b97dc31d756e") -- Battlefield 1 - ru_RU
setManifestid(1238847, "570821728554432234", 0)
addappid(1238848, 1, "7a3effb7b26ecf44ae09dce6df39f2332990f6d0b726aa1ed58b4bed0e4b7fd4") -- Battlefield 1 - pl_PL
setManifestid(1238848, "4619855109816350718", 0)
addappid(1238849, 1, "515d63c59eb085af6028f57b150a01b3328092809a46703898535f551c716c78") -- Battlefield 1 - ja_JP
setManifestid(1238849, "3339085658486066800", 0)
addappid(1238852, 1, "a4f7c4516dc72e16700c4b4deac33c20287074574decf9b49369653662e721eb") -- Battlefield 1 - zh_TW
setManifestid(1238852, "58933347447130494", 0)
addappid(1238853, 1, "24c8d7cafd56006a415371f91b4a2a6077ecf8099f3fdc99d7740fd026690518") -- Battlefield 1 - pt_BR
setManifestid(1238853, "8279800455333304274", 0)
addappid(1238854, 1, "ca70e1e20dc6794bc88d442fe505eb85c5142cc741a1a7169ccf753678a4e869") -- Battlefield 1 - es_MX
setManifestid(1238854, "1650768952195373472", 0)
addappid(1238855, 1, "8c35c4d65346b6f733c667251a3ef34e990280a9546b1be048e6f0e4424b0988") -- Battlefield 1 - ar_SA
setManifestid(1238855, "5103094569245063720", 0)
addappid(1238856, 1, "18125f3b57aa45e546e63f41fa0182224fe3a06ce4b0484f58d4769232ac4cfd") -- Battlefield 1 - tr_TR
setManifestid(1238856, "8599216250777182138", 0)

-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1238850) -- Battlefield 1 Premium Pass
addappid(1238851) -- Battlefield 1  Shortcut Kit Ultimate Bundle
addappid(1259490) -- Battlefield 1 - Key
addappid(1259491) -- Battlefield 1 Revolution - Key
addappid(1259492) -- Battlefield 1 They Shall Not Pass
addappid(1259493) -- Battlefield 1 Turning Tides
addappid(1259494) -- Battlefield 1 Apocalypse
addappid(1259495) -- Battlefield 1 In the Name of the Tsar
addappid(1259496) -- Battlefield 1 Hellfighter Pack
addappid(1259497) -- Battlefield 1 Expansion Pack
addappid(1259498) -- Battlefield 1 Heroes of the Great War Bundle
addappid(1259499) -- Battlefield 1 Deluxe Upgrade
addappid(1314760) -- Battlefield 1 Shortcut Kit Assault Bundle
addappid(1314761) -- Battlefield 1 Shortcut Kit Support Bundle
addappid(1314762) -- Battlefield 1 Shortcut Kit Medic Bundle
addappid(1314763) -- Battlefield 1 Shortcut Kit Scout Bundle
addappid(1314764) -- Battlefield 1 Shortcut Kit Infantry Bundle
addappid(1314765) -- Battlefield 1 Shortcut Kit Vehicle Bundle
