-- Generated Lua Manifest by Mythydra
-- Steam App 916440 Manifest
-- Name: Anno 1800
-- Generated: 2025-08-27 00:53:46
-- Total Depots: 6
-- Total DLCs: 36 (1 encrypted, 35 free)
-- Source: JSON depot data + Steam API

-- MAIN APPLICATION
addappid(916440) -- Anno 1800

-- MAIN APP DEPOTS
addappid(916441,0,"fdf2da2bad8516bd58704e87cdd2101173aa1330d9328186184ff6445a945e19") -- Anno 1800 Game Depot
setManifestid(916441,"602107637723357028")
addappid(916442,0,"eb8f0f30eafebbbaf8c5870c365708e8a973fd5d817e79d08db91170da90284b") -- Anno 1800 Game Depot
setManifestid(916442,"2296595173881018171")
addappid(916443,0,"070c294380877e9c7d8f2daab4a07fe0b2194473c79502b71e66b11d5ec4bbf0") -- Anno 1800 Game Depot
setManifestid(916443,"417837324765211653")
addappid(916444,0,"5f6372b7a1ed235b555d05aa54ec7bea9f3d4b08906633514b058b5bd14f4e6c") -- Anno 1800 Game Depot
setManifestid(916444,"5902021179752818974")
addappid(916445,0,"2bb378d0ec6043f34d63cbf2c37a06e9d61c9c197188638cdd24b6fccc0ccbbf") -- Anno 1800 Game Depot
setManifestid(916445,"7376275033869973185")

-- DLCS WITH DEDICATED DEPOTS (From JSON)
-- Anno 1800 Soundtrack & Artbook (AppID: 916446)
addappid(916446,0,"96ca058661170b58b95d8745bf9a352795ee003dfbf96c622825b88063eada12") -- Anno 1800 Soundtrack & Artbook - 229.31 MiB
setManifestid(916446,"5306902030699936255")

-- DLCS WITHOUT DEDICATED DEPOTS (From Steam API)
addappid(1933240) -- Anno 1800™ - Season 4 Pass
addappid(1530880) -- Anno 1800™ - Season 3 Pass
addappid(1247710) -- Anno 1800™ - Season 2 Pass
addappid(1066850) -- Anno 1800™ - Season 1 Pass
addappid(3256930) -- Anno 1800 - End of an Era Pack
addappid(3113620) -- Anno 1800 - Pirate Cove Pack
addappid(2830580) -- Anno 1800 - Steampunk Pack
addappid(2622040) -- Anno 1800 - Eldritch Pack
addappid(2504950) -- Anno 1800™ National Park Pack
addappid(2400950) -- Anno 1800™ Fiesta Pack
addappid(1933242) -- Anno 1800 Cosmetic Pack Bundle #1
addappid(2622020) -- Anno 1800 Cosmetic Pack Bundle #2
addappid(2277980) -- Anno 1800™ Dragon Garden Pack
addappid(2222650) -- Anno 1800 - Old Town Pack
addappid(2055760) -- Anno 1800 - Industrial Zone Pack
addappid(1803742) -- Anno 1800 - Vibrant Cities Pack
addappid(1704690) -- Anno 1800 - Pedestrian Zone Pack
addappid(1626972) -- Anno 1800 - Vehicle Liveries
addappid(1465650) -- Anno 1800 - City Lights Pack
addappid(1383240) -- Anno 1800 - Amusements Pack
addappid(1210040) -- Anno 1800 – Holiday pack
addappid(1881100) -- Anno 1800 - Seasonal Decorations Pack
addappid(1125790) -- Anno 1800 - Sunken Treasure
addappid(1125792) -- Anno 1800 - Botanica
addappid(1125794) -- Anno 1800 - The Passage
addappid(1247680) -- Anno 1800 - Seat of Power
addappid(1314950) -- Anno 1800 - Bright Harvest
addappid(1442810) -- Anno 1800 - Land of Lions
addappid(1530882) -- Anno 1800 - Docklands
addappid(1626970) -- Anno 1800 - Tourist Season
addappid(1704680) -- Anno 1800 - The High Life
addappid(1933244) -- Anno 1800 - Seeds of Change
addappid(2074410) -- Anno 1800 - Empire of the Skies
addappid(2222640) -- Anno 1800 – New World Rising
addappid(1066852) -- Anno 1800 - Deluxe Pack