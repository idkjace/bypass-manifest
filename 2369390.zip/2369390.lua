-- Generated Lua Manifest by Solus Bot in Morrenus Games
-- Steam App 2369390 Manifest
-- Name: Far Cry 6
-- Generated: 2025-07-02 10:11:31
-- Total Depots: 4
-- Total DLCs: 19
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2369390) -- Far Cry 6

-- MAIN APP DEPOTS
addappid(2369391, 1, "c3d84384b92e4ab8aa58ab4d8602f408821c5ce3b7a213d07d79926a6198180b") -- Depot 2369391
setManifestid(2369391, "5783041166523199015", 0)

-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675") -- Ubisoft Connect PC Client Content (Shared from App 1716750)
setManifestid(1716751, "818295193716041715", 0)

-- DLCS WITH DEDICATED DEPOTS
-- Far Cry 6 - HD Textures (AppID: 2432590)
addappid(2432590)
addappid(2432590, 1, "3b4498e4cb314f981631df47a5a260f6f0ea14bbbb77e50efa0c2810741435d4") -- Far Cry 6 - HD Textures - Depot 2432590
setManifestid(2432590, "7910386811588276346", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2369450) -- Far Cry 6 Lost Between Worlds
addappid(2369451) -- Far Cry 6 Lost Between Worlds - Ubisoft Activation
addappid(2369452) -- Far Cry 6 Game of the Year Upgrade Pass
addappid(2369453) -- Far Cry 6 Game of the Year Upgrade Pass - Ubisoft Activation
addappid(2369454) -- Far Cry 6 DLC 3 Joseph Collapse
addappid(2369455) -- Far Cry 6 DLC 3 Joseph Collapse - Ubisoft Activation
addappid(2369456) -- Far Cry 6 DLC 2 Pagan Control
addappid(2369457) -- Far Cry 6 DLC 2 Pagan Control - Ubisoft Activation
addappid(2369458) -- Far Cry 6 DLC 1 Vaas Insanity
addappid(2369459) -- Far Cry 6 DLC 1 Vaas Insanity - Ubisoft Activation
addappid(2369470) -- Far Cry 6 - Season Pass
addappid(2369471) -- Far Cry 6 - Season Pass Ubisoft Activation
addappid(2369472) -- Far Cry 6 - Starter Pack
addappid(2369473) -- Far Cry 6 Starter Pack - Ubisoft Activation
addappid(2369530) -- Far Cry 6 Standard Edition Ubisoft Activation
addappid(2369531) -- Far Cry 6 Deluxe Edition Ubisoft Activation
addappid(2369532) -- Far Cry 6 Gold Edition Ubisoft Activation
addappid(2369533) -- Far Cry 6 Game of the Year Edition Ubisoft Activation
