-- Generated Lua Manifest by Mythydra
-- Steam App 2679460 Manifest
-- Name: Metaphor: ReFantazio
-- Generated: 2025-09-08 09:31:53
-- Total Depots: 15
-- Total DLCs: 14 (12 encrypted, 2 free)
-- Source: Steam AppInfo (steam-user)

-- MAIN APPLICATION
addappid(2679460) -- Metaphor: ReFantazio

-- MAIN APP DEPOTS
addappid(228989,1,"ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- Metaphor: ReFantazio Game Depot
setManifestid(228989,"3514306556860204959")
addappid(2679461,1,"0a945c91ddfaaca28d19da03981f783f8eb23a6dcc1121fb8c0936bb17fe0adb") -- Metaphor: ReFantazio Game Depot
setManifestid(2679461,"920857891814528270")

-- DLCS WITH DEDICATED DEPOTS (From AppInfo)
-- Metaphor: ReFantazio - Shujin Academy School Uniform (7), Battle BGM & Battle Jingle Set  (AppID: 2924400)
addappid(2924400)
addappid(2924400,1,"9e10f74a58642944210d4ac83c2afe05a39a9260522357676d71f7a173b06377") -- Metaphor: ReFantazio - Shujin Academy School Uniform (7), Battle BGM & Battle Jingle Set  - Depot 2924400
setManifestid(2924400,"8468482355859270207")

-- Metaphor: ReFantazio - Yasogami High School Uniform (7), Battle BGM & Battle Jingle Set (AppID: 2924410)
addappid(2924410)
addappid(2924410,1,"f874d47604752cc8683b1f01d6c0af1ba2e70fe2f0b05bb24c9dda0f216f2f6e") -- Metaphor: ReFantazio - Yasogami High School Uniform (7), Battle BGM & Battle Jingle Set - Depot 2924410
setManifestid(2924410,"1675665214669305266")

-- Metaphor: ReFantazio - Gekkoukan High School Uniform (7), Battle BGM & Battle Jingle Set (AppID: 2924420)
addappid(2924420)
addappid(2924420,1,"8d03e6189c0de6ad5de6aef6856b1e737e34fbbc88de72dc4b65ac0dde275909") -- Metaphor: ReFantazio - Gekkoukan High School Uniform (7), Battle BGM & Battle Jingle Set - Depot 2924420
setManifestid(2924420,"6621481143717332374")

-- Metaphor: ReFantazio - Seven Sisters High School Uniform (7), Battle BGM & Battle Jingle Set (AppID: 2924430)
addappid(2924430)
addappid(2924430,1,"d938b2988775f6ee36386f348d136198b811e977d25792973d3efbf25b5ee23d") -- Metaphor: ReFantazio - Seven Sisters High School Uniform (7), Battle BGM & Battle Jingle Set - Depot 2924430
setManifestid(2924430,"3704313378978754357")

-- Metaphor: ReFantazio - St. Hermelin High School Uniform (7), Battle BGM & Battle Jingle Set (AppID: 2924440)
addappid(2924440)
addappid(2924440,1,"f2c1a9b7a12874361ff385a135a0360c33ba6ed85da22e746c14971e5cafec7a") -- Metaphor: ReFantazio - St. Hermelin High School Uniform (7), Battle BGM & Battle Jingle Set - Depot 2924440
setManifestid(2924440,"8554757429954255931")

-- Metaphor: ReFantazio - Jouin High School Uniform (7), Battle BGM & Battle Jingle Set (AppID: 2924450)
addappid(2924450)
addappid(2924450,1,"465e853c2d357a47955eb08ad98b3937f3107d290fade3a96de4439bf7222200") -- Metaphor: ReFantazio - Jouin High School Uniform (7), Battle BGM & Battle Jingle Set - Depot 2924450
setManifestid(2924450,"3319877433662834664")

-- Metaphor: ReFantazio - Samurai Garb (7), Battle BGM & Battle Jingle Set (AppID: 2924460)
addappid(2924460)
addappid(2924460,1,"73b0d5feef1f30f9d2c4a0f864cb8811a39e5705be3938a6257fbc82395278ba") -- Metaphor: ReFantazio - Samurai Garb (7), Battle BGM & Battle Jingle Set - Depot 2924460
setManifestid(2924460,"981534630072667278")

-- Metaphor: ReFantazio - Etrian Odyssey Class Costumes (7) & Battle BGM Set (AppID: 2924470)
addappid(2924470)
addappid(2924470,1,"16a09d4bd6677c201ad2b9b6164fd3e363aa0e76ce4e703134893da89548fb97") -- Metaphor: ReFantazio - Etrian Odyssey Class Costumes (7) & Battle BGM Set - Depot 2924470
setManifestid(2924470,"5807167524975752183")

-- Metaphor: ReFantazio - Digital Artbook (AppID: 2999630)
addappid(2999630)
addappid(2999630,1,"b7dd710afb9dcb1e0106c84e2354771188f530aa7da4260f05281dda109f69c3") -- Metaphor: ReFantazio - Digital Artbook - Depot 2999630
setManifestid(2999630,"194251860336420911")

-- Metaphor: ReFantazio - Digital Soundtrack (AppID: 2999640)
addappid(2999640)
addappid(2999640,1,"52fc013d9924ce3cabc75b710214d182cdf62cae67e14fcaeb8ae77e3b546e56") -- Metaphor: ReFantazio - Digital Soundtrack - Depot 2999640
setManifestid(2999640,"7098567140540487946")

-- Atlus 35th Digital History Book (AppID: 2999650)
addappid(2999650)
addappid(2999650,1,"a2ac12bbb27f3659bc064fef1f20c10644a81b66411a1a38a76da5d395f52b2f") -- Atlus 35th Digital History Book - Depot 2999650
setManifestid(2999650,"4786858738006469344")

-- Atlus 35th Digital All-Time Best Soundtrack (AppID: 2999660)
addappid(2999660)
addappid(2999660,1,"64e42d838da4dc83cc7878389b50de24d9aebe6102a7ed346f3d5f69b830d5b6") -- Atlus 35th Digital All-Time Best Soundtrack - Depot 2999660
setManifestid(2999660,"329033940057783353")

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2924480) -- Metaphor: ReFantazio - Archetype EXP Chest Set
addappid(2924490) -- Metaphor: ReFantazio - Adventurer’s Journey Pack